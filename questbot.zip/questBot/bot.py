import telebot
from telebot import types

token = '5161545869:AAFa7_NZpaXfZkVk27yOvmoOlmrVRVmB7zg'
bot = telebot.TeleBot(token)


# блок 1-2
@bot.message_handler(commands=['start', 'restart'])
def start_message(message):
    markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
    item1 = types.KeyboardButton("Да")
    markup.add(item1)
    bot.send_message(message.chat.id, "Это игра-квест. Я буду рассказывать вам, что происходит в игре, а вы будете "
                                      "отвечать, что должен сделать ваш персонаж."
                                      "Вам нужно будет разобраться в том, что происходит. Итак, начинаем?",
                     reply_markup=markup)
    bot.register_next_step_handler(message, message_begin)


# блок 3
@bot.message_handler(content_types='text')
def message_begin(message):
    markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
    item1 = types.KeyboardButton("Изучить приборы")
    item2 = types.KeyboardButton("Нажать кнопку")
    markup.add(item1)
    markup.add(item2)
    if message.text == "Изучить приборы":
        bot.send_message(message.chat.id, "Уровень кислорода 105% оптимального. Регидрация завершена на 80%. Сознание "
                                          "устойчиво регистрируется. Пульс 109 ударов в минуту", reply_markup=markup)
    elif message.text == "Нажать кнопку":
        bot.register_next_step_handler(message, exit_capsuleV1)
    bot.send_message(message.chat.id, "Начинаем. Тишина. Сознание постепенно возвращается. Вы приходите в себя. Вы не "
                                      "можете вспомнить, кто вы и где находитесь. Вы заперты в каком-то тесном "
                                      "металлическом ящике. Шевелить получается только правой рукой. Но лежать здесь "
                                      "удобно, и на тюрьму непохоже. Вот только очень хочется пить. Перед вами на "
                                      "внутренней стороне крышки приборная панель с многочисленными индикаторами, "
                                      "слева от них - единственная кнопка.", reply_markup=markup)


# блок 5
@bot.message_handler(content_types='text')
def exit_capsuleV1(message):
    markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
    item1 = types.KeyboardButton("Пойти налево")
    item2 = types.KeyboardButton("Пойти направо")
    item3 = types.KeyboardButton("Осмотреть саркофаг")
    markup.add(item1)
    markup.add(item2)
    markup.add(item3)
    bot.send_message(message.chat.id, "Медленно, с шипением крышка открывается, и вы понимаете, что можете встать. Вы "
                                      "в узком коридоре, проходы ведут налево и направо. Позади вас открытый "
                                      "саркофаг, в котором вы лежали.", reply_markup=markup)
    if message.text == "Пойти налево":
        bot.register_next_step_handler(message, cameras)
    elif message.text == "Пойти направо":
        bot.register_next_step_handler(message, cabin)
    elif message.text == "Осмотреть саркофаг":
        bot.send_message(message.chat.id,
                         "Ложе пластиковое, оно повторяет форму человеческого тела. Вы никак не ожидали, что внутри "
                         "так много игл и трубок. Похоже пока вы были  внутри, они поддерживали в вас жизнь. На стене "
                         "над ним металлическая табличка, на которой написано “Резерв”. Сейчас саркофаг отключен и с "
                         "ним ничего не происходит.", reply_markup=markup)


# блок 6
@bot.message_handler(content_types='text')
def cameras(message):
    markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
    item1 = types.KeyboardButton("Идти дальше")
    item2 = types.KeyboardButton("Вернуться назад")
    markup.add(item1)
    markup.add(item2)
    bot.send_message(message.chat.id, "Вы проходите по коридору и видите ещё два саркофага. Они закрыты. Над ними "
                                      "таблички с буквами “А” и  “Б”. Крышки непрозрачны, нельзя понять есть ли "
                                      "кто-нибудь внутри. Они ничем в остальном не отличаются от вашего.",
                     reply_markup=markup)
    if message.text == "Идти дальше":
        bot.register_next_step_handler(message, teleport_off)
    elif message.text == "Вернуться назад":
        bot.register_next_step_handler(message, exit_capsuleV2)


# блок 7
@bot.message_handler(content_types='text')
def exit_capsuleV2(message):
    markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
    item1 = types.KeyboardButton("Пойти налево")
    item2 = types.KeyboardButton("Пойти направо")
    item3 = types.KeyboardButton("Осмотреть саркофаг")
    markup.add(item1)
    markup.add(item2)
    markup.add(item3)
    bot.send_message(message.chat.id, "Вы в коридоре с анабиозными камерами, проходы ведут налево и направо. Позади "
                                      "вас открытый саркофаг.", reply_markup=markup)
    if message.text == "Пойти налево":
        bot.register_next_step_handler(message, cameras)
    elif message.text == "Пойти направо":
        bot.register_next_step_handler(message, cabin)
    elif message.text == "Осмотреть саркофаг":
        bot.send_message(message.chat.id,
                         "Ложе пластиковое, оно повторяет форму человеческого тела. Вы никак не ожидали, что внутри "
                         "так много игл и трубок. Похоже пока вы были  внутри, они поддерживали в вас жизнь. На стене "
                         "над ним металлическая табличка, на которой написано “Резерв”. Сейчас саркофаг отключен и с "
                         "ним ничего не происходит.", reply_markup=markup)


# блок 8
@bot.message_handler(content_types='text')
def cabin(message):
    markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
    item1 = types.KeyboardButton("Осмотреть стол")
    item2 = types.KeyboardButton("Осмотреть тренажер")
    item3 = types.KeyboardButton("Подняться по лестнице")
    item4 = types.KeyboardButton("Вернуться в коридор")
    markup.add(item1)
    markup.add(item2)
    markup.add(item3)
    markup.add(item4)
    bot.send_message(message.chat.id, "Вы в небольшом помещении, напоминает кают-компанию. Здесь стоит стол, "
                                      "вокруг него расположены три кресла, на стене висит несколько фотографий в "
                                      "рамочках, в углу вы видите лестницу, которая ведёт куда-то наверх, "
                                      "в другом углу стоит спортивный тренажёр.", reply_markup=markup)
    if message.text == "Осмотреть стол":
        bot.register_next_step_handler(message, table)
    elif message.text == "Осмотреть тренажер":
        bot.register_next_step_handler(message, train)
    elif message.text == "Подняться по лестнице":
        bot.register_next_step_handler(message, upstairs)
    elif message.text == "Вернуться в коридор":
        bot.register_next_step_handler(message, exit_capsuleV2)


# блок 9
@bot.message_handler(content_types='text')
def upstairs(message):
    markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
    item1 = types.KeyboardButton("Посмотреть на звезды")
    item2 = types.KeyboardButton("Сесть в кресло")
    item3 = types.KeyboardButton("Спуститься вниз")
    markup.add(item1)
    markup.add(item2)
    markup.add(item3)
    bot.send_message(message.chat.id, "Вы поднимаетесь по лестнице, попадаете в небольшое полукруглое помещение, "
                                      "и у вас захватывает дух. Вся дальняя от вас сторона - одно огромное окно, "
                                      "за которым бесконечные неподвижные звёзды. Вы в рубке космического корабля. "
                                      "Всё это время вы находились в космосе. Перед вами пульт управления с двумя "
                                      "креслами.", reply_markup=markup)
    if message.text == "Осмотреть стол":
        bot.register_next_step_handler(message, window)
    elif message.text == "Осмотреть тренажер":
        bot.register_next_step_handler(message, pilotV1)
    elif message.text == "Подняться по лестнице":
        bot.register_next_step_handler(message, cabin)


# блок 10
@bot.message_handler(content_types='text')
def pilotV1(message):
    markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
    item1 = types.KeyboardButton("Подергать рычаги")
    item2 = types.KeyboardButton("Рассмотреть тумблеры")
    item3 = types.KeyboardButton("Пересесть на соседнее кресло")
    item4 = types.KeyboardButton("Спуститься вниз")
    markup.add(item1)
    markup.add(item2)
    markup.add(item3)
    markup.add(item4)
    bot.send_message(message.chat.id, "Сидеть в кресле неудобно, оно для вас великовато. Похоже, это кресло первого "
                                      "пилота: перед вами множество рычагов и тумблеров.", reply_markup=markup)
    if message.text == "Подергать рычаги":
        bot.send_message(message.chat.id,
                         "Вы слышите громкий, явно синтезированный голос: «Не член экипажа. Управление заблокировано».",
                         reply_markup=markup)
    elif message.text == "Рассмотреть тумблеры":
        bot.register_next_step_handler(message, tumblr)
    elif message.text == "Пересесть на соседнее кресло":
        bot.register_next_step_handler(message, mechanic)
    elif message.text == "Спуститься вниз":
        bot.register_next_step_handler(message, cabin)


# блок 11
@bot.message_handler(content_types='text')
def mechanic(message):
    markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
    item1 = types.KeyboardButton("Включить экран")
    item2 = types.KeyboardButton("Пересеть на соседнее кресло")
    item3 = types.KeyboardButton("Спуститься вниз")
    markup.add(item1)
    markup.add(item2)
    markup.add(item3)
    bot.send_message(message.chat.id, "Перед этим креслом большой черный экран. Он выключен.", reply_markup=markup)
    if message.text == "Включить экран":
        bot.register_next_step_handler(message, computer)
    elif message.text == "Пересеть на соседнее кресло":
        bot.register_next_step_handler(message, pilotV1)
    elif message.text == "Спуститься вниз":
        bot.register_next_step_handler(message, cabin)


# блок 12
@bot.message_handler(content_types='text')
def computer(message):
    markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
    item1 = types.KeyboardButton("Рассказать об экипаже")
    item2 = types.KeyboardButton("Цель экспедиции")
    item3 = types.KeyboardButton("Медицинская диагностика")
    item4 = types.KeyboardButton("Пересесть на соседнее кресло")
    item5 = types.KeyboardButton("Спуститься вниз")
    markup.add(item1)
    markup.add(item2)
    markup.add(item3)
    markup.add(item4)
    markup.add(item5)
    bot.send_message(message.chat.id, "Экран включается. По нему пробегают логи загрузки, длинные столбцы цифр "
                                      "диагностики, и высвечивается приветствие:'Бортовой компьютер слушает вас'",
                     reply_markup=markup)
    if message.text == "Рассказать об экипаже":
        bot.send_message(message.chat.id, "Филодор Зеленый. Борт-механик "
                                          "Игорь Селезнев. Профессор и капитан корабля "
                                          "КРИТИЧЕСКАЯ ОШИБКА 0х000", reply_markup=markup)
    elif message.text == "Цель экспедиции":
        bot.send_message(message.chat.id, "Целью экспедиции является прокладка квантового тоннеля к четвёртой планете "
                                          "системы Тау Кита, потенциально пригодной для колонизации. В случае "
                                          "успешного завершения телепортация сделает систему доступной для жителей "
                                          "Земли. Плановое прибытие через 51 год.", reply_markup=markup)
    elif message.text == "Медицинская диагностика":
        bot.send_message(message.chat.id, "Запускаю диагностику. Обнаружена поломка анабиозных камер, приведшая к"
                                          "остановке жизнедеятельности экипажа.", reply_markup=markup)
    elif message.text == "Пересесть на соседнее кресло":
        bot.send_message(message.chat.id, "Бортовой компьютер выключается", reply_markup=markup)
        bot.register_next_step_handler(message, pilotV1)
    elif message.text == "Спуститься вниз":
        bot.send_message(message.chat.id, "Бортовой компьютер выключается", reply_markup=markup)
        bot.register_next_step_handler(message, cabin)


# блок 16
@bot.message_handler(content_types='text')
def tumblr(message):
    markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
    item1 = types.KeyboardButton("МАРШДВИГ")
    item2 = types.KeyboardButton("ТРЕВОГА")
    item3 = types.KeyboardButton("ПАРАШЮТ")
    item4 = types.KeyboardButton("назад")
    markup.add(item1)
    markup.add(item2)
    markup.add(item3)
    markup.add(item4)
    bot.send_message(message.chat.id, "Рядом с большинством тумблеров неизвестные вам цифры и аббревиатуры.Только три "
                                      "тумблера подписаны насколько-то понятно: МАРШДВИГ, ТРЕВОГА и ПАРАШЮТ.",
                     reply_markup=markup)
    if message.text == "МАРШДВИГ":
        bot.send_message(message.chat.id, "Вы слышите громкий, явно синтезированный голос: «Не член экипажа. "
                                          "Управление заблокировано».", reply_markup=markup)
    elif message.text == "ТРЕВОГА":
        bot.register_next_step_handler(message, alert)  # !!!
    elif message.text == "ПАРАШЮТ":
        bot.send_message(message.chat.id, "Вы слышите громкий, явно синтезированный голос: «Не член экипажа. "
                                          "Управление заблокировано».", reply_markup=markup)
    elif message.text == "назад":
        bot.register_next_step_handler(message, pilotV1)


# блок 17
@bot.message_handler(content_types='text')
def alert(message):
    markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
    item1 = types.KeyboardButton("Нажать тумблер снова")
    item2 = types.KeyboardButton("Спуститься вниз")
    markup.add(item1)
    markup.add(item2)
    bot.send_message(message.chat.id, "Внезапно все панели и экраны выключаются и вдоль стен на уровне пояса "
                                      "загорается цепь красных огоньков. Звучит сирена. Звук громкий и неприятный. К "
                                      "счастью, не очень долгий, но каждые несколько секунд он повторяется.",
                     reply_markup=markup)
    if message.text == "Нажать тумблер снова":
        bot.send_message(message.chat.id, "Всё возвращается в норму. Панели и экраны снова включились.",
                         reply_markup=markup)
        bot.register_next_step_handler(message, tumblr)
    elif message.text == "Спуститься вниз":
        bot.register_next_step_handler(message, cabin_alert)


# блок 18
def cabin_alert(message):
    markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
    item1 = types.KeyboardButton("Идти в коридор")
    item2 = types.KeyboardButton("Подняться наверх")
    markup.add(item1)
    markup.add(item2)
    bot.send_message(message.chat.id, "Вы в кают-компании. Вся мебель куда-то пропала.Выходы ведут вверх по лестнице "
                                      "и через дверь в коридор.",
                     reply_markup=markup)
    if message.text == "Идти в коридор":
        bot.register_next_step_handler(message, exit_capsule_alert)
    elif message.text == "Подняться наверх":
        bot.register_next_step_handler(message, upstairs_alert)


# блок 19
def upstairs_alert(message):
    markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
    item1 = types.KeyboardButton("Сесть за кресло пилота")
    item2 = types.KeyboardButton("Спуститься вниз")
    markup.add(item1)
    markup.add(item2)
    bot.send_message(message.chat.id, "Сирена продолжает реветь. Цепь красных огоньков ухудшает видимость однако "
                                      "кресла экипажа отчетливо видно.",
                     reply_markup=markup)
    if message.text == "Сесть за кресло пилота":
        bot.register_next_step_handler(message, pilot_alert)
    elif message.text == "Спуститься вниз":
        bot.register_next_step_handler(message, cabin_alert)


# блок 20
def pilot_alert(message):
    markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
    item1 = types.KeyboardButton("Переключить тумблер")
    item2 = types.KeyboardButton("Спуститься вниз")
    markup.add(item1)
    markup.add(item2)
    bot.send_message(message.chat.id, "На панели пилота отчётливо виден тумблер ТРЕВОГА.",
                     reply_markup=markup)
    if message.text == "Переключить тумблер":
        bot.send_message(message.chat.id, "Всё возвращается в норму. Панели и экраны снова включились.",
                         reply_markup=markup)
        bot.register_next_step_handler(message, tumblr)
    elif message.text == "Спуститься вниз":
        bot.register_next_step_handler(message, cabin_alert)


# блок 21
def exit_capsule_alert(message):
    markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
    item1 = types.KeyboardButton("Пойти налево")
    item2 = types.KeyboardButton("Пойти направо")
    markup.add(item1)
    markup.add(item2)
    bot.send_message(message.chat.id, "Вы в коридоре с анабиозными камерами, проходы ведут налево и направо. Позади "
                                      "вас открытый саркофаг. Сирена, полумрак и красные огни по стенам наводят жуть.",
                     reply_markup=markup)
    if message.text == "Пойти налево":
        bot.register_next_step_handler(message, cameras_alert)
    elif message.text == "Пойти налево":
        bot.register_next_step_handler(message, cabin_alert)


# блок 22
def cameras_alert(message):
    markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
    item1 = types.KeyboardButton("Пойти налево")
    item2 = types.KeyboardButton("Пойти направо")
    markup.add(item1)
    markup.add(item2)
    bot.send_message(message.chat.id, "Вы проходите по коридору и видите два саркофага. Они закрыты. Периодически "
                                      "ревет сирена. Это очень неуютно.",
                     reply_markup=markup)
    if message.text == "Идти дальше":
        bot.register_next_step_handler(message, teleport_on_1)
    elif message.text == "Вернуться назад":
        bot.register_next_step_handler(message, exit_capsule_alert)


# блок 23
def teleport_on_1(message):
    markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
    item1 = types.KeyboardButton("Нажать на кнопку")
    item2 = types.KeyboardButton("Вернуться назад")
    markup.add(item1)
    markup.add(item2)
    bot.send_message(message.chat.id, "В стене перед вами небольшие круглые ворота. Звучит сирена. Створки ворот "
                                      "дрожат, между ними просвечивает холодное синее свечение. Рядом с ними - "
                                      "огромная красная кнопка. Проход дальше перекрыт запечатанным шлюзом.",
                     reply_markup=markup)
    if message.text == "Нажать на кнопку":
        bot.register_next_step_handler(message, teleport_on_2)
    elif message.text == "Вернуться назад":
        bot.register_next_step_handler(message, cameras_alert)


# блок 24
def teleport_on_2(message):
    markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
    item1 = types.KeyboardButton("Нажать на кнопку")
    item2 = types.KeyboardButton("Вернуться назад")
    markup.add(item1)
    markup.add(item2)
    bot.send_message(message.chat.id, "Вы нажимаете на кнопку. Вы слышите синтезированный голос: «Внимание, эвакуация "
                                      "приводит к уничтожению физического тела. Продолжить?»",
                     reply_markup=markup)
    if message.text == "Продолжить":
        bot.register_next_step_handler(message, teleport_on_3)
    elif message.text == "Нет":
        bot.register_next_step_handler(message, teleport_on_1)


# блок 25
def teleport_on_3(message):
    markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
    item1 = types.KeyboardButton("Нажать на кнопку")
    item2 = types.KeyboardButton("Вернуться назад")
    markup.add(item1)
    markup.add(item2)
    bot.send_message(message.chat.id, "В силу квантовой неопределённости точное положение компьютерной сети "
                                      "назначения в пространстве-времени определиться автоматически только в момент "
                                      "переноса. Ожидаемый разброс: планета Земля, конец двадцатого - начало двадцать "
                                      "третьего века. Выразите своё явное юридическое согласие на телепортацию.",
                     reply_markup=markup)
    if message.text == "Продолжить":
        bot.register_next_step_handler(message, teleport_name)
    elif message.text == "Нет":
        bot.register_next_step_handler(message, teleport_on_1)


# блок 26
def teleport_name(message):
    markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
    item1 = types.KeyboardButton("назад")
    markup.add(item1)
    bot.send_message(message.chat.id, "«Назовите своё имя»",
                     reply_markup=markup)
    if message.text == "Алиса" or message.text == "Алиса Селезнева":
        bot.register_next_step_handler(message, teleport_on_3)
    elif message.text == "назад":
        bot.register_next_step_handler(message, teleport_on_1)
    else:
        bot.send_message(message.chat.id, "«Проверка личности не пройдена». Голос умолкает.",
                         reply_markup=markup)
        bot.register_next_step_handler(message, teleport_name)


# блок 27
def teleport_name(message):
    markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
    item1 = types.KeyboardButton("Сделать шаг")
    markup.add(item1)
    bot.send_message(message.chat.id, "Звук сирены меняет тон. Створки открываются. Вы видите портал. Он заполнен "
                                      "ярким синим свечением, больше похожим не на пламя, а на фонтан. Остаётся "
                                      "только сделать шаг - и ваше сознание окажется на Земле, оставив тело здесь.",
                     reply_markup=markup)
    if message.text == "Сделать шаг":
        bot.send_message(message.chat.id, "Что ж, здесь и заканчивается моя история. Считайте, что вы победили! А где "
                                          "оказалась героиня, в каком времени, и вечно ли ей быть бесплотным духом, "
                                          "живущим в компьютерной сети - додумывайте сами. Если хотите начать квест "
                                          "заново пропишите /restart",
                         reply_markup=markup)


# блок 28
def teleport_off(message):
    markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
    item1 = types.KeyboardButton("Нажать кнопку")
    item2 = types.KeyboardButton("Вернуться к анабиозным камерам")
    markup.add(item1)
    markup.add(item2)
    bot.send_message(message.chat.id, "В стене перед вами небольшие круглые ворота. Створки плотно закрыты. Рядом с "
                                      "ними - огромная красная кнопка.",
                     reply_markup=markup)
    if message.text == "Нажать кнопку":
        bot.send_message(message.chat.id, "Вы нажимаете кнопку, ничего не происходит.",
                         reply_markup=markup)
    elif message.text == "Вернуться к анабиозным камерам":
        bot.register_next_step_handler(message, cameras)


# блок 29
def table(message):
    markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
    item1 = types.KeyboardButton("Взять чашку")
    item2 = types.KeyboardButton("Отойти от стола")
    markup.add(item1)
    markup.add(item2)
    bot.send_message(message.chat.id, "На столе вы замечаете металлическую чашку и осознаёте, насколько вам хочется "
                                      "пить.",
                     reply_markup=markup)
    if message.text == "Взять чашку":
        bot.register_next_step_handler(message, tap)
    elif message.text == "Отойти от стола":
        bot.register_next_step_handler(message, cameras)


# блок 30
def tap(message):
    markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
    item1 = types.KeyboardButton("Подойти к крану")
    markup.add(item1)
    bot.send_message(message.chat.id, "Чашка оказывается примагниченной к столу,но снимается с него без усилий. В "
                                      "соседнюю стену встроено что-то вроде крана. То, что нужно!",
                     reply_markup=markup)
    if message.text == "Подойти к крану":
        bot.send_message(message.chat.id, "Вы жадно выпиваете несколько чашек одну за другой.",
                         reply_markup=markup)
        bot.register_next_step_handler(message, cabin)


# блок 31
def train(message):
    markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
    item1 = types.KeyboardButton("Сесть на тренажер")
    item2 = types.KeyboardButton("Отойти от тренажера")
    markup.add(item1)
    bot.send_message(message.chat.id, "Вы подходите к тренажёру. Он небольшой, но позволяет тренировать сразу все "
                                      "группы мышц.",
                     reply_markup=markup)
    if message.text == "Сесть на тренажер":
        bot.send_message(message.chat.id, "Из любопытства вы пытаетесь сдвинуть рычаги тренажёра, но это оказывается "
                                          "слишком тяжело. Неужели вы так ослабли?",
                         reply_markup=markup)
        bot.register_next_step_handler(message, cabin)
    elif message.text == "Отойти от тренажера":
        bot.register_next_step_handler(message, cabin)


# блок 32
def window(message):
    markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
    item1 = types.KeyboardButton("Сесть в кресло")
    item2 = types.KeyboardButton("Спуститься вниз")
    markup.add(item1)
    markup.add(item2)
    bot.send_message(message.chat.id, "Вы не можете найти ни одного знакомого созвездия. А ведь раньше вы знали их "
                                      "все наизусть, даже те, что в Южном полушарии. Кто же вы? Как вас зовут? Что вы "
                                      "тут делаете? Вы чувствуете одиночество.",
                     reply_markup=markup)
    if message.text == "Сесть в кресло":
        bot.register_next_step_handler(message, pilotV1)
    elif message.text == "Спуститься вниз":
        bot.register_next_step_handler(message, cabin)


bot.polling(none_stop=True, interval=0)
