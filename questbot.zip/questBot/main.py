import telebot
from telebot import types
token = '5161545869:AAFa7_NZpaXfZkVk27yOvmoOlmrVRVmB7zg'
bot = telebot.TeleBot(token)


# блок 1-2
@bot.message_handler(commands=['start'])
async def send_welcome(message):
    menu = types.ReplyKeyboardMarkup(resize_keyboard=True)
    item_begin = types.KeyboardButton("Да")
    menu.add(item_begin)
    bot.send_message(message.chat.id, "Это игра-квест. Я буду рассказывать вам, что происходит в игре, а вы будете "
                                      "отвечать, что должен сделать ваш "
                                      "персонаж. Можно говорить всё, что приходит в голову, например, “иду вверх по "
                                      "лестнице”, или “жму на кнопку”. "
                                      "Вам нужно будет разобраться в том, что происходит. Итак, начинаем?",
                     reply_markup=types.ReplyKeyboardRemove())
    bot.register_next_step_handler(message, start)


# блок 3
async def start(message):
    keyboard = types.ReplyKeyboardMarkup(resize_keyboard=True)
    buttons = ["Да"]
    keyboard.add(*buttons)
    await message.answer(
        "Начинаем. Тишина. Сознание постепенно возвращается. Вы приходите в себя. Вы не можете вспомнить, "
        "кто вы и где находитесь. Вы заперты в каком-то тесном металлическом ящике. Шевелить получается только правой "
        "рукой. Но лежать здесь удобно, и на тюрьму непохоже. Вот только очень хочется пить. Перед вами на внутренней "
        "стороне крышки приборная панель с многочисленными индикаторами, слева от них - единственная кнопка.",
        reply_markup=types.ReplyKeyboardRemove())


bot.polling(none_stop=True, interval=0)
