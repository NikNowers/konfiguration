# This is a sample Python script.

# Press Shift+F10 to execute it or replace it with your code.
# Press Double Shift to search everywhere for classes, files, tool windows, actions, and settings.
import cmath

# 1
# x = 0.62
# def main(x):
# return(((71 * ((x ** 2 / 91) + 1 + x) ** 2 -
# (1 - 84 * (x ** 3) - x ** 2) ** 7)
# / (79 * (x ** 4))) ** 0.5 - 85 * (abs(x) ** 4))

# 2
# def main(x):
#   if x < 52:
#      return x ** 4 - ((x ** 2 / 88) - 8 - x ** 3) ** 3 - 86 * (x ** 2)
# if 52 <= x < 77:
#    return 51 * (70 - x) - 81 * (35 * x + x ** 3 + x ** 2) ** 6
# if x >= 77:
# return abs(x) ** 2
# 3
import math


# def main(m, b, n, z):
#   summ = 0
#   for i in range(1, n + 1):
#      for c in range(1, b + 1):
#         for k in range(1, m + 1):
#                   (c + k ** 3 + (65 * (k ** 2))) ** 4
# return summ

# def main(m, b, n, z):
#     k = 1
#     c = 1
#     i = 1
#     summ = 0
#     while i <= n:
#         while c <= b:
#             while k <= m:
#                 summ += math.exp(i) ** 5 + z ** 2 +\
#                         (c + k ** 3 + (65 * k ** 2)) ** 4
#                 k += 1
#             c += 1
#         i += 1
#     return summ

# def main(n):
#   if n == 0:
#      return 0.55
# if n >= 1:
#    return main(n-1) + ((main(n-1)**3 + main(n-1) + 1)**2) / 71

# import math


# def main(x):
#   sum = 0
#  n = len(x)
# for i in range(n):
#    sum += (49*(x[math.floor(i/4)]**2) + x[math.floor(i/4)]**3 + 1)**7
# return 5 * sum

# print (main([0.54, -0.16, 0.39, 0.47, -0.17]))

def main(x):
    x3a = {'ROFF': 0,
           'LLVM': 1}
    x3b = {'ROFF': 2,
           'LLVM': 3}
    x1a = {'SCSS': x3a[x[3]],
           'IO': x3b[x[3]]}
    x2 = {'E': 4,
          'RUST': 5}
    x1 = {'SCSS': 6,
          'IO': 7}
    x3c = {'ROFF': x2[x[2]],
           'LLVM': x1[x[1]]}
    x3d = {'ROFF': 8,
           'LLVM': 9}
    x0 = {1996: x1a[x[1]],
          2004: x3c[x[3]],
          1983: x3d[x[3]]}
    return x0[x[0]]
print(main([1983, 'SCSS', 'E', 'ROFF']))
