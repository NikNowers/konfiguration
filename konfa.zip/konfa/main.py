import sys
import tarfile


def help():
    print('''
ls - list files and directories
cat 'file' - read file
cd path - change directory
exit - exit CLI
help - call this text
pwd - show current directory
	''')


def cd(text, path):
    oldpath = path
    if (text[0] == '/'):
        path = text
    elif (text == ".."):
        path = '/'.join(path.split('/')[:-1])
    elif (path == "/"):
        path = path + text
    else:
        path = path + "/" + text
    if (path == ""): path = '/'

    for i in zip.getnames():
        if i.startswith(path[1:]) and (not '.' in i):
            return path
    print("cd: can't change directory")
    return oldpath


def cat(file, folder):
    if (file[0] == '/'):
        target = file[1:]
    elif (folder == ""):
        target = file
    else:
        target = folder + '/' + file
    try:
        print(zip.extractfile(target).read().decode("utf-8"))
    except KeyError:
        print("cat: can't open file")


def ls(text, folder):
    if not (text == "ls"):
        text = text.split(' ')[1]
        if (text[0] == '/'):
            target = text
        elif (folder == ""):
            target = text
        elif (folder == "/"):
            target = folder + text
        else:
            target = folder + '/' + text

    else:
        target = folder
    check = False
    for i in zip.getnames():
        if i.startswith(target[1:]) and (not '.' in i):
            check = True
    if check == False:
        print("ls: can't list directory")
        return

    print("Folder:", target)
    target = target[1:]
    for i in zip.getnames():
        if i.startswith(target) and (i != target) and (((target + "/") in i) or target == "") and not (
                "/" in i[len(target) + 1:]):
            if (target == ""):
                print(i[len(target):])
            else:
                print(i[len(target) + 1:])


def main():
    fs = ''.join(sys.argv[1:])
    # fs = "fs.tar"
    try:
        if not (tarfile.is_tarfile(fs)):
            raise Exception("not a archive")
    except:
        print("PyOS: can't load archive")
        return
    global zip
    with tarfile.open(fs, "r") as zip:
        path = "/"
        while True:
            try:
                i = input(f'PyOS >> ')  # user_input
                if "cd" in i:
                    path = cd(i.split(' ')[1], path)
                elif "exit" == i:
                    return
                elif 'cat' in i:
                    cat(i.split(' ')[1], path[1:])
                elif 'ls' in i:
                    ls(i, path)
                elif 'pwd' == i:
                    print(path)
                elif 'help' == i:
                    help()
                else:
                    print("Unknown command")
            except KeyboardInterrupt:
                print();
                return


if __name__ == '__main__':
    main()

