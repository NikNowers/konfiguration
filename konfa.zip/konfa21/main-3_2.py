import os
import sys
import urllib.request
import zipfile
import requests


# находим наш файл с служебной информаией
def find_META(dirlist):
    for elem in dirlist:
        if "METADATA" in elem:
            return elem
    return None


# выводим что ему нужно для работы, кроме языка Python как это делает pip без extra
def out_dependences(lines):
    answ = []
    for elem in lines:
        if ("requires-dist" in elem.lower()) and ("python" not in elem.lower()) and ("extra" not in elem.lower()):
            temp = elem.split()
            for i in range(len(temp)):
                if "requires-dist" in temp[i].lower():
                    answ.append(temp[i + 1].replace('-', '_'))
                    break
    return answ


# получим имя пакета из его файла служебных файлов
def get_name(lines):
    for elem in lines:
        if "name" in elem.lower():
            temp = elem.split()
            for i in range(len(temp)):
                if "name" in temp[i].lower():
                    return temp[i + 1]


# создадим наш grapx массив
def format_graphx(name, mas):
    if len(mas) == 0:
        pass
    else:
        answ = []
        for line in mas:
            answ.append(name.replace('-', '_') + "->" + line)
        return list(set(answ))


def get_file_name(name, mas):
    for elem in mas:
        if name.lower() in elem.lower():
            return elem


# Сайт на котором мы можем найти любые существующие пакеты для python
URL = "https://pypi.org/simple/"
all_dep = []


# Функция находящая URL нужный для скачки
def get_URL_to_download(content):
    content = content.replace(" ", '\n')
    content = content.split('\n')
    answ = ""
    for i in range(len(content)):
        if "href=" in content[-1 - i] and "whl" in content[-1 - i]:
            answ = content[-1 - i]
            break
    answ = answ.replace("href=", "")
    answ = answ[1:-1]
    return answ


def main(name):
    global all_dep
    try:
        # находим скаченный пакет по имени на его url
        response = requests.get(URL + name + '/')
        # получаем URL для скачки
        new_URL = get_URL_to_download(response.content.decode("UTF-8"))
        # скачиваем наш файлик и считываем его
        urllib.request.urlretrieve(new_URL, name + ".zip")
        file = zipfile.ZipFile(name + ".zip", 'r')
        # прочитаем его инфо файл и преобразуем
        metadata = file.open(find_META(file.namelist()), 'r')
        text = metadata.readlines()
        metadata.close()
        for i in range(len(text)):
            text[i] = text[i].decode('UTF-8')
        # Создадим и выведим наш graphx файл
        dependences = out_dependences(text)
        graph = (format_graphx(get_name(text), dependences))
        if graph is not None:
            for i in range(len(graph)):
                all_dep.append(graph[i])
                main(dependences[i])
        file.close()
        # дополнительно удаляю файл чтобы не занимал место можно в теории отключить
        os.remove(name + ".zip")
    except ValueError:
        print("Неправильно введено название пакета")
    finally:
        pass


var = sys.argv[1]
main(var)
all_dep = list(set(all_dep))
print(var + '\n')
print("digraph Ex{")
for elem in all_dep:
    print(elem)
print('}')
